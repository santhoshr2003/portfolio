// Wait for the DOM to be fully loaded
document.addEventListener("DOMContentLoaded", function () {
    var preloader = document.querySelector('.preloader');

    window.addEventListener("load", function () {
        preloader.style.display = "none";
    });
});

let prevScrollPos = window.pageYOffset;
const nav = document.getElementById('header');
const mainContent = document.querySelector('.main-content');

window.onscroll = () => {
    const currentScrollPos = window.pageYOffset;

    if (prevScrollPos > currentScrollPos) {
        nav.style.transform = 'translateY(0)';
        mainContent.style.marginTop = '0';
    } else {
        nav.style.transform = 'translateY(-60px)'; 
        mainContent.style.marginTop = '60px'; 
    }

    prevScrollPos = currentScrollPos;
};
